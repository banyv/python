from os import close
import torch
from torch._C import device
import torchvision
import torchvision.transforms as transforms
import  torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import torch.optim as optim
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from torch.utils.tensorboard import SummaryWriter


classes =('NO','YES')




#定义一个类，用来建立一个简单的神经网络，固定套路

class Net(nn.Module):                    #继承torch.Module的内置方法

    def __init__(self):            #继承nn.Module的内置方法
        super().__init__()

        self.conv1 = nn.Conv2d(3, 6, 5)#卷积层第一层，二维卷积，卷积在二维平面上移动

        self.pool = nn.MaxPool2d(2, 2) #池化层，对应的是二维卷积的池化层，对卷积进行筛选

        self.conv2 = nn.Conv2d(6, 16, 5)  #卷积层第二层，二维卷积

        #线性变换，对传入数据应用线性变换，用于设置网络中的全连接层
        #全连接层作用是将经过多个卷积层和池化层的图像特征图中的特征进行整合，获取图像特征具有的高层含义，之后用于图像分类

        self.fc0 = nn.Linear(1296, 900)
        self.fc1 = nn.Linear(900, 600)
        self.fc2 = nn.Linear(600, 300)
        self.fc3 = nn.Linear(300, 2)


    def forward(self, x):
        x=self.pool(F.relu(self.conv1(x)))   # 首先对输入层做一次卷积运算，再进行激励（非线性映射），再池化
        x=self.pool(F.relu(self.conv2(x)))   # 然后对第一次操作（卷积、激励、池化）的结果做第二次卷积，同样卷积、激励、池化
        x=x.view(-1, 1296)
        # 如果输出是一个维度
        # 通过一个sigmoid函数，输出大小范围在0-1之间，以0.5为界限，》0.5是一类，小于0.5是一类
        x=F.relu(self.fc0(x))
        x=F.relu(self.fc1(x))
        x=F.relu(self.fc2(x))
        x=self.fc3(x)
        return x

def loadtestdata():
    path=r"D:\miniconda\envs\pytorch\untitled1\test"
    testset=torchvision.datasets.ImageFolder( path,
                                              transform=transforms.Compose([
                                                  transforms.Resize((50,50)),
                                                  transforms.ToTensor()
                                              ]))
    testloader=torch.utils.data.DataLoader( testset,
                                            batch_size=25,
                                            shuffle=True,
                                            num_workers=2)
    return testloader
#取出训练的整个神经网络的模型结构以及参数
def reload_net():
    net=Net()
    net=net.cuda()
    checkpoint=torch.load('net_params.pkl')
    net.load_state_dict(checkpoint)
    return net



#用来显示图片
def imshow(img):
    img=img/2+0.5
    npimg=img.numpy()
    plt.imshow(np.transpose(npimg,(1,2,0)))
    plt.show()


def test():
    testloader=loadtestdata()        #取出测试数据
    net=reload_net()                #取出神经网络参数
    dataiter=iter(testloader)      #返回了基于可迭代对象生成的迭代器
    images,labels=dataiter.next()    #迭代器通过next（）来遍历数组
    print('GroundTruth: ', " ".join('%-10s' % classes[labels[j]] for j in range(25)))   #打印25个图的实际jieggu
    outputs=net(Variable(images).cuda())
    _, predicted = torch.max(outputs.data, 1)

    print('  Predicted: ', " ".join('%-10s' % classes[predicted[j]] for j in range(25)))  # 打印25个图的预测结果

    imshow(torchvision.utils.make_grid(images, nrow=5))


if __name__ == '__main__':
    print(torch.cuda.is_available())
    test()








