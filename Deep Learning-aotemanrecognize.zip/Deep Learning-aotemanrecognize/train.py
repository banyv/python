from os import close
import os
import torch
import  torchvision
import torchvision.transforms as transforms
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import torch.optim as optim
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from torch.utils.tensorboard import  SummaryWriter
import torch.utils.data as data
from torchvision.transforms.transforms import RandomCrop

use_gpu=torch.cuda.is_available()


#定义一个函数，用来获取训练用的图像，批数据的训练
def loadtraindata():
    path = r"D:\miniconda\envs\pytorch\untitled1\train"
    trainset=torchvision.datasets.ImageFolder(path,                               # 图像目录路径
                                                transform=transforms.Compose([      # transforms.Compose：接收PIL图像并返回转换版本的函数/转换（将几个变换组合在一起），参数是一个transforms对象
                                                                                    # API说明：https://pytorch.org/vision/stable/transforms.html#torchvision.transforms.Compose
                                                    transforms.Resize((50, 50)),    # 将图片缩放到指定大小（h,w）
                                                    #transforms.CenterCrop(32),      # 剪裁
                                                    #transforms.RandomCrop(50),     # 对过拟合有帮助，相当于做了图像增强
                                                    transforms.ToTensor()])         # 将PIL图像或 numpy.ndarray 转换为 tenser 张量
                                                )

    trainloader=torch.utils.data.DataLoader( trainset,#训练集
                                             batch_size=4,  #指一次拿多少数据出来
                                             shuffle=True,  #要不要打乱数据
                                             num_workers=2  #多线程来读数据
                                             )
    return trainloader

class Net(nn.Module):      #继承nn.Module的内置方法，

    def __init__(self):
        super().__init__()

        self.conv1 = nn.Conv2d(3, 6, 5)   #卷积层第一层，这里是二维卷积，卷积在二维平面上移动，图像是二维的


        self.pool = nn.MaxPool2d(2, 2)     #池化层，对应的是二维卷积的池化层，对卷积层进行筛选

        self.conv2 = nn.Conv2d(6, 16, 5)  #卷积层第二层，二维卷积


        #线性变换，对传入数据进行应用线性变换，用于设置网络中的全连接层
        # 在基本的CNN网络中，全连接层的作用是将经过多个卷积层和池化层的图像特征图中的特征进行整合，获取图像特征具有的高层含义，之后用于图像分类

        self.fc0 = nn.Linear(1296, 900)
        self.fc1 = nn.Linear(900, 600)
        self.fc2 = nn.Linear(600, 300)
        self.fc3 = nn.Linear(300, 2)

    def forward(self,x):
        x = self.pool(F.relu(self.conv1(x)))  # 首先对输入层做一次卷积运算，再进行激励（非线性映射），再池化
        x = self.pool(F.relu(self.conv2(x)))  # 然后对第一次操作（卷积、激励、池化）的结果做第二次卷积，同样卷积、激励、池化
        x = x.view(-1, 1296)



        # 将 torch 变量转为一个400列的张量
        x = F.relu(self.fc0(x))
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x



#开始训练的函数
def trainandsave():
    writer = SummaryWriter('runs/aoteman_1')  #实例化summary，将条目直接写入日志目录中的事件文件，以供TensorBoard使用
                                            #默认情况下，Writer将输出到./runs/目录


    trainloader=loadtraindata()  #获取训练用图像
    net = Net()                     #实例化神经网络对象
    if (use_gpu):
        net.cuda()
    optimizer = optim.SGD(net.parameters(),lr=0.001,momentum=0.9) #实例化神经网络优化器，优化神经网络，使他快起来

    criterion = nn.CrossEntropyLoss()   #实例化损失函数
    if (use_gpu):
        criterion = criterion.cuda()


    for epoch in range(10):    #训练100步
        running_loss = 0.0   #每次训练初始值为0
        for i,data in enumerate(trainloader,0):   #函数用于将一个可遍历的数据对象(如列表、元组或字符串)组合为一个索引序列，同时列出数据和数据下标，一般用在 for 循环当中


            inputs,labels=data
            inputs,labels=Variable(inputs),Variable(labels)  # 在 Torch 中的 Variable 就是一个存放会变化的值的地理位置，里面的值会不停的变化。Variable是可更改的，而Tensor是不可更改的。
            if(use_gpu):
                inputs=inputs.cuda()
                labels=labels.cuda()

            img_grid=torchvision.utils.make_grid(inputs)    #若干幅图片拼成一个，在需要展示一批数据的时候有用

            writer.add_image('aoteman',img_grid)           ## 将图像数据添加到summary，以供TensorBoard使用


            optimizer.zero_grad()                     #所有优化的张量的梯度设置为0
            outputs=net(inputs)                       #相当于调用Net()的forward方法

            loss=criterion(outputs,labels)              #损失函数：实际输出（概率）与期望输出（概率）的距离


            loss.backward()       #反向传播，计算当前梯度



            optimizer.step()    #单次优化
            running_loss+=loss.item()      # 计算这次训练loss的平均值，前面有清零操作

            if i%40==39:
                print('[%d, %5d] loss: %.3f' % (epoch + 1, i + 1, running_loss / 40))
                torch.save(net.state_dict(), 'net_params.pkl')  # 只保存模型参数


if __name__ == '__main__':
                # use_gpu=0
    print(use_gpu)
    trainandsave()
